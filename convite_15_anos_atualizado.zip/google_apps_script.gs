function doPost(e) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
  const data = e && e.parameter ? e.parameter : {};
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(['Data e hora', 'Nome', 'Telefone', 'Gênero', 'Presença', 'Acompanhantes', 'Músicas sugeridas', 'E-mail']);
  }
  sheet.appendRow([
    new Date(),
    data.nome || '',
    data.telefone || '',
    data.genero || '',
    data.presenca || '',
    data.acompanhantes || '',
    data.musicas || '',
    data.email || ''
  ]);
  return ContentService.createTextOutput('OK').setMimeType(ContentService.MimeType.TEXT);
}
